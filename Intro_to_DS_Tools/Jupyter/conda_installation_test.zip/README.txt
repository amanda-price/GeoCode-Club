README for testing the installation of the conda package:

To test if the conda package was installed correctly, execute the bash script 'test_installation.sh' in your console or terminal.

'source test_installation.sh'

It first activates the obspy environment, then checks the installed packages und opens a jupyter notebook in your browser afterwards.
If a python package is not installed, it will tell you in the terminal window.
If the jupyter notebook opens, everything should work well and you can close the browser window.

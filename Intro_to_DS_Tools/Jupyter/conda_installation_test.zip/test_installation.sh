#this is a short bash script for testing the conda installation
#execute with 'source test_installation.sh' or './test_installation.sh'


echo "Activating colorado environment"
source activate colorado
echo "Checking if needed python packages are installed"
python test_installation.py
echo "Check if Jupyter Notebook works"
#jupyter notebook &> /dev/null &
#PID=$!
#echo "A browser window with a jupyter notebook should open. You can close it."


jupyter notebook &> /dev/null &
PID=$!
echo "A browser window with a jupyter notebook should open. You can close it."
echo "The notebook server is still active even after closing the
notebook in the browser. You can terminate it by 'kill $PID'"

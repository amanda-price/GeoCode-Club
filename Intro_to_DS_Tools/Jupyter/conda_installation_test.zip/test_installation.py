def module_exists(module_name):
    try:
        __import__(module_name)
    except ImportError:
        return False
    else:
        return True
    

modules=('sys', 'numpy', 'scipy', 'pandas', 'obspy', 'matplotlib', 'urllib')
idx=0
exists=True
while exists:
    exists = module_exists(modules[idx])
    if exists==True:
        print(modules[idx], 'installed')
    if exists==False:
        print(modules[idx], 'not installed! Please install it with "conda {} install".'.format(modules[idx]))
        
    if idx<len(modules)-1:
        idx+=1
    elif idx==len(modules)-1:
        print('ALL NEEDED PYTHON MODULES ARE INSTALLED')
        break
